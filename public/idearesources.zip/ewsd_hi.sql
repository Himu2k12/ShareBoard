-- phpMyAdmin SQL Dump
-- version 4.5.1
-- http://www.phpmyadmin.net
--
-- Host: 127.0.0.1
-- Generation Time: Mar 12, 2018 at 07:37 AM
-- Server version: 10.1.13-MariaDB
-- PHP Version: 7.0.5

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `ewsd_hi`
--

-- --------------------------------------------------------

--
-- Table structure for table `categories`
--

CREATE TABLE `categories` (
  `id` int(11) NOT NULL,
  `name` varchar(50) NOT NULL,
  `description` varchar(200) NOT NULL,
  `start_date` date NOT NULL,
  `end_date` date NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `categories`
--

INSERT INTO `categories` (`id`, `name`, `description`, `start_date`, `end_date`) VALUES
(1, 'Environment', 'hhhh', '2018-03-12', '2018-06-15'),
(2, 'library', 'fghjkl', '2018-03-08', '2018-08-18'),
(3, 'Accounts', 'fgh', '2018-03-07', '2018-03-23'),
(4, 'L5DC', 'hi i am L5DC', '2018-03-05', '2018-03-11');

-- --------------------------------------------------------

--
-- Table structure for table `comments`
--

CREATE TABLE `comments` (
  `id` int(11) NOT NULL,
  `reply` text NOT NULL,
  `idea_id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `user_name` varchar(50) NOT NULL,
  `staffOnstudent_comment` tinyint(4) NOT NULL,
  `anonymous_comment` tinyint(4) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `comments`
--

INSERT INTO `comments` (`id`, `reply`, `idea_id`, `user_id`, `user_name`, `staffOnstudent_comment`, `anonymous_comment`) VALUES
(1, 'yes we can\r\n', 2, 2, 'tahasin', 1, 0),
(2, 'we can do a lot', 2, 3, 'prity', 0, 0),
(3, 'i also agree', 2, 4, 'Onty akter', 1, 0),
(4, 'hvjhgjhgjh', 2, 3, 'prity', 0, 0),
(5, 'kjkzjds', 2, 3, 'prity', 0, 0),
(6, 'kjdsda', 2, 3, 'prity', 0, 1),
(7, 'kljdnakdn', 2, 2, 'tahasin', 1, 1);

-- --------------------------------------------------------

--
-- Table structure for table `department`
--

CREATE TABLE `department` (
  `id` int(11) NOT NULL,
  `department_name` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `department`
--

INSERT INTO `department` (`id`, `department_name`) VALUES
(1, 'BIT'),
(2, 'CSE'),
(3, 'IT'),
(4, 'EEE');

-- --------------------------------------------------------

--
-- Table structure for table `ideas`
--

CREATE TABLE `ideas` (
  `id` int(10) NOT NULL,
  `idea_name` varchar(100) NOT NULL,
  `idea_details` text NOT NULL,
  `file_name` varchar(100) DEFAULT NULL,
  `categories_id` int(11) NOT NULL,
  `students_id` int(11) NOT NULL,
  `publication_status` tinyint(4) NOT NULL DEFAULT '0',
  `anonymous_post` tinyint(4) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `ideas`
--

INSERT INTO `ideas` (`id`, `idea_name`, `idea_details`, `file_name`, `categories_id`, `students_id`, `publication_status`, `anonymous_post`) VALUES
(2, 'Book borrow', 'Can borrow any book', '', 2, 1, 1, 1),
(3, 'Environment problem ', 'Its like a market not a varsity', '', 1, 1, 1, 0),
(4, 'klajdsflKLDFkldjflkjdfs', 'flkdsjflkj', 'Asset/Images/28343058_2110937829125875_1316640630_o.png', 2, 3, 1, 0),
(5, 'kjsdk', 'kdjfkfss', 'Asset/Images/EWSD (1).docx', 1, 3, 1, 0),
(6, 'lkdjlaj ', 'dlksjfsld', 'Asset/Images/EWSD_000989811_Deluar-Jahan_COMP-1640_April_2017.pdf', 2, 3, 1, 0),
(7, 'sports', 'sports club', 'Asset/Images/28381542_2110937725792552_1188100972_n.png', 1, 6, 1, 0),
(8, 'hawa hawai', 'lkgjfgj;lkj', 'Asset/Images/20171126_134314.jpg', 2, 3, 1, 0),
(9, 'efgdfgetw', 'dwerfwe', 'Asset/Images/2018-02-09-08-34-11-843.jpg', 2, 3, 1, 0),
(10, 'Book', 'All types of books cannot hire', 'Asset/Images/EWSD_000989811_Deluar-Jahan_COMP-1640_April_2017.pdf', 2, 1, 1, 0),
(11, 'Admission', 'Take so many money', 'Asset/Images/Test-Plan-and-Test-Log_Appendix.pdf', 3, 7, 1, 0),
(12, 'Stall remove', 'In the campus there are o lot of stall, it decrease the varsity beauty', 'Asset/Images/03.jpg', 1, 9, 1, 0),
(13, 'dasda', 'sdsdfs', NULL, 1, 3, 0, 0),
(14, 'himangshu', 'jkahsdj dkjfah ', NULL, 2, 3, 0, 1),
(15, 'jhdasd', 'adjfasdfasd', NULL, 1, 3, 0, 1),
(16, 'kjda', 'jkasdfa', NULL, 1, 3, 0, 1),
(17, 'hi i am done', 'asdfasdfa sd', NULL, 1, 3, 0, 0),
(18, 'Nobody', 'kjadf ajkdfa', NULL, 1, 3, 0, 0),
(19, 'mhdabsk', 'hjadsfjdshf', NULL, 2, 3, 0, 0),
(20, 'afjksdf', 'jksddfa', NULL, 1, 3, 0, 1),
(21, 'kjada', 'kjasdfa', NULL, 1, 3, 0, 1),
(22, 'ahsdfhj', 'jhadsfj', NULL, 1, 3, 0, 1),
(23, 'lkasd', 'jksasdkja', NULL, 1, 3, 0, 1),
(24, 'kja', 'jksd', NULL, 2, 3, 0, 1),
(25, 'kjdsahas', 'jhadfa', NULL, 1, 3, 0, 0),
(26, 'jahdsbf', 'jkdasf', NULL, 1, 3, 0, 0);

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `id` int(11) NOT NULL,
  `name` varchar(150) NOT NULL,
  `email` varchar(200) NOT NULL,
  `pass` varchar(100) NOT NULL,
  `role` tinyint(4) NOT NULL,
  `department_id` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `name`, `email`, `pass`, `role`, `department_id`) VALUES
(1, 'tasmim', 'tasmim@gmail.com', 'tasmim', 1, 1),
(2, 'tahasin', 'tahasin@gmail.com', 'tahasin', 0, 0),
(3, 'prity', 'prity@gmail.com', 'prity', 1, 2),
(4, 'Onty akter', 'opu@gmail.com', '123', 3, 1),
(7, 'taposi', 'taposi@gmail.com', 'taposi', 3, 4),
(8, 'tushi', 'tushi@gmail.com', 'tushi', 3, 2),
(9, 'nissan', 'nissan@gmail.com', 'nissan', 1, 3),
(10, 'shormi', 'shormi@gmail.com', '123', 3, 0);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `categories`
--
ALTER TABLE `categories`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `comments`
--
ALTER TABLE `comments`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `department`
--
ALTER TABLE `department`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `ideas`
--
ALTER TABLE `ideas`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `categories`
--
ALTER TABLE `categories`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;
--
-- AUTO_INCREMENT for table `comments`
--
ALTER TABLE `comments`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;
--
-- AUTO_INCREMENT for table `department`
--
ALTER TABLE `department`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;
--
-- AUTO_INCREMENT for table `ideas`
--
ALTER TABLE `ideas`
  MODIFY `id` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=27;
--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=11;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
