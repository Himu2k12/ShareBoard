-- phpMyAdmin SQL Dump
-- version 4.5.1
-- http://www.phpmyadmin.net
--
-- Host: 127.0.0.1
-- Generation Time: Apr 04, 2018 at 11:44 AM
-- Server version: 10.1.13-MariaDB
-- PHP Version: 7.0.5

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `ewsd`
--

-- --------------------------------------------------------

--
-- Table structure for table `admins`
--

CREATE TABLE `admins` (
  `id` int(10) UNSIGNED NOT NULL,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `email` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `admin_type` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `password` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `categories`
--

CREATE TABLE `categories` (
  `id` int(10) UNSIGNED NOT NULL,
  `category_name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `category_description` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `start_date` date NOT NULL,
  `end_date` date NOT NULL,
  `publication_status` tinyint(4) NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `categories`
--

INSERT INTO `categories` (`id`, `category_name`, `category_description`, `start_date`, `end_date`, `publication_status`, `created_at`, `updated_at`) VALUES
(1, 'jkjkk', 'sksjadns akjdn aksjdfn asdnf kasndfk', '0000-00-00', '0000-00-00', 0, '2018-03-05 13:15:22', '2018-03-07 00:37:04'),
(3, 'himu', 'himu is a gainer', '2018-03-07', '2018-03-10', 1, '2018-03-07 00:55:12', '2018-03-07 00:55:12'),
(4, 'Don', 'sdf  asdf asdf', '2018-03-21', '2018-03-30', 1, '2018-03-07 13:35:41', '2018-03-07 13:35:41'),
(5, 'joy bangla', 'Amar sonar bangla Amar sonar banglaAmar sonar banglaAmar sonar banglaAmar sonar banglaAmar sonar banglaAmar sonar banglaAmar sonar banglaAmar sonar banglaAmar sonar banglaAmar sonar bangla', '2018-03-09', '2018-03-14', 1, '2018-03-10 22:23:52', '2018-03-10 22:23:52'),
(6, 'i am human', 'ioasdfi sadlkfh askdjk asdhf khasdfkjhaskjdfhakjs', '2018-03-11', '2018-03-29', 1, '2018-03-10 22:32:23', '2018-03-10 22:32:23'),
(7, 'hasbjA', 'HJAJSj', '2018-03-02', '2018-03-11', 1, '2018-03-10 22:33:12', '2018-03-10 22:33:12');

-- --------------------------------------------------------

--
-- Table structure for table `comments`
--

CREATE TABLE `comments` (
  `id` int(10) UNSIGNED NOT NULL,
  `idea_id` int(10) UNSIGNED NOT NULL,
  `reply_description` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `user_id` int(10) UNSIGNED NOT NULL,
  `anonymous` tinyint(4) NOT NULL DEFAULT '1',
  `staff_comment` tinyint(4) NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `comments`
--

INSERT INTO `comments` (`id`, `idea_id`, `reply_description`, `user_id`, `anonymous`, `staff_comment`, `created_at`, `updated_at`) VALUES
(1, 1, 'my name is himu', 1, 0, 0, '2018-03-06 02:33:23', '2018-03-06 02:33:23'),
(2, 1, 'hi i am done', 1, 0, 0, '2018-03-06 02:44:06', '2018-03-06 02:44:06'),
(3, 1, 'kjdkfjad kajsdfhakjsd', 4, 0, 0, '2018-03-06 02:54:52', '2018-03-06 02:54:52'),
(4, 1, 'hi', 5, 0, 0, '2018-03-06 22:31:02', '2018-03-06 22:31:02'),
(5, 1, 'i am', 5, 0, 0, '2018-03-06 22:34:28', '2018-03-06 22:34:28'),
(6, 1, 'hi i am done', 1, 0, 0, '2018-03-08 04:12:53', '2018-03-08 04:12:53'),
(7, 4, 'my name is himu', 1, 0, 0, '2018-03-10 10:21:58', '2018-03-10 10:21:58'),
(8, 5, 'asdfijasdohf adsuhfasodhf', 1, 0, 0, '2018-03-10 10:24:57', '2018-03-10 10:24:57'),
(9, 6, 'hi i am done', 1, 0, 0, '2018-03-10 10:25:07', '2018-03-10 10:25:07'),
(10, 9, 'kkjdfadfadsf', 1, 1, 0, '2018-03-10 10:42:53', '2018-03-10 10:42:53'),
(11, 9, 'hi i am done', 1, 0, 0, '2018-03-10 10:46:49', '2018-03-10 10:46:49'),
(12, 9, 'hi i made it', 1, 1, 0, '2018-03-10 11:06:21', '2018-03-10 11:06:21'),
(13, 9, 'i am nobody baby', 1, 1, 0, '2018-03-10 11:06:34', '2018-03-10 11:06:34'),
(14, 9, 'h', 1, 0, 0, '2018-03-10 11:06:56', '2018-03-10 11:06:56'),
(15, 9, 'HH', 1, 1, 0, '2018-03-10 11:10:52', '2018-03-10 11:10:52'),
(16, 9, 'HI', 1, 1, 0, '2018-03-10 11:12:20', '2018-03-10 11:12:20'),
(17, 9, 'hawa', 1, 1, 0, '2018-03-10 11:15:34', '2018-03-10 11:15:34'),
(18, 9, 'kjsd', 1, 1, 0, '2018-03-10 11:16:30', '2018-03-10 11:16:30'),
(19, 4, 'ajkdf', 1, 1, 0, '2018-03-10 11:17:01', '2018-03-10 11:17:01'),
(20, 4, 'iahdsfa', 1, 1, 0, '2018-03-10 11:17:06', '2018-03-10 11:17:06'),
(21, 4, 'i am not here', 1, 1, 0, '2018-03-10 11:17:54', '2018-03-10 11:17:54'),
(22, 4, 'hi', 1, 0, 0, '2018-03-10 11:19:55', '2018-03-10 11:19:55'),
(23, 4, 'adsfadsf', 1, 1, 0, '2018-03-10 11:20:02', '2018-03-10 11:20:02'),
(24, 4, 'jhadsfhak sdf', 7, 0, 0, '2018-03-10 11:20:48', '2018-03-10 11:20:48'),
(25, 4, 'jhfk haskdjfh kjdhfska jdfa', 7, 1, 0, '2018-03-10 11:20:54', '2018-03-10 11:20:54'),
(26, 9, 'ss', 7, 1, 0, '2018-03-10 12:42:40', '2018-03-10 12:42:40'),
(27, 9, 'hi', 2, 1, 1, '2018-03-10 22:55:39', '2018-03-10 22:55:39'),
(28, 9, 'kj', 2, 1, 1, '2018-03-10 22:57:35', '2018-03-10 22:57:35'),
(29, 9, 'j', 2, 1, 1, '2018-03-10 22:59:11', '2018-03-10 22:59:11'),
(30, 9, 'hjads', 2, 0, 1, '2018-03-10 22:59:54', '2018-03-10 22:59:54'),
(31, 9, 'jkjk', 2, 1, 1, '2018-03-10 23:00:22', '2018-03-10 23:00:22'),
(32, 16, 'jfdlkasjdfaklsdf', 1, 0, 0, '2018-03-12 07:02:21', '2018-03-12 07:02:21'),
(33, 16, 'jhfksjdhfgjskdf', 1, 1, 0, '2018-03-12 07:02:27', '2018-03-12 07:02:27'),
(34, 17, 'hi i am done', 2, 1, 1, '2018-03-12 07:05:12', '2018-03-12 07:05:12'),
(35, 17, 'joy bangla', 1, 0, 0, '2018-03-17 04:41:49', '2018-03-17 04:41:49'),
(36, 18, 'this is good', 2, 1, 1, '2018-03-18 06:55:26', '2018-03-18 06:55:26'),
(37, 18, 'this is bad', 2, 0, 1, '2018-03-18 06:55:36', '2018-03-18 06:55:36'),
(38, 18, 'shdzsdhz', 9, 0, 0, '2018-03-18 06:56:12', '2018-03-18 06:56:12'),
(39, 18, 'hgsahgdaj', 1, 1, 0, '2018-03-18 06:56:46', '2018-03-18 06:56:46'),
(40, 23, 'its ok', 10, 1, 0, '2018-03-20 08:23:35', '2018-03-20 08:23:35'),
(41, 23, 'come on this is not funny', 1, 1, 0, '2018-03-20 08:39:08', '2018-03-20 08:39:08'),
(42, 31, 'this is good', 1, 1, 0, '2018-03-20 11:01:39', '2018-03-20 11:01:39'),
(43, 31, 'this is good', 1, 1, 0, '2018-03-20 11:02:20', '2018-03-20 11:02:20'),
(44, 18, 'jkhaksdfkasdfhhjsd', 1, 0, 0, '2018-03-20 12:53:40', '2018-03-20 12:53:40'),
(45, 32, 'ok', 2, 1, 1, '2018-03-22 22:59:27', '2018-03-22 22:59:27'),
(46, 32, 'hjhjjh', 7, 0, 0, '2018-03-23 02:22:44', '2018-03-23 02:22:44'),
(47, 32, 'kjkj', 7, 1, 0, '2018-03-23 02:23:49', '2018-03-23 02:23:49'),
(48, 32, 'Welcome to Shortparagraph.com! Our mission is to provide an online platform to help students to discuss anything and everything about Paragraph. This website includes study notes, research papers, essays, articles and other allied information submitted by visitors like YOU.', 1, 1, 0, '2018-03-27 12:34:47', '2018-03-27 12:34:47'),
(49, 32, 'ekdinb to morei jabo', 1, 1, 0, '2018-03-27 12:34:53', '2018-03-27 12:34:53'),
(50, 32, 'hi i am done', 7, 1, 0, '2018-03-28 06:34:04', '2018-03-28 06:34:04'),
(51, 2, 'hi i am done', 2, 0, 0, '2018-04-01 13:14:46', '2018-04-01 13:14:46');

-- --------------------------------------------------------

--
-- Table structure for table `departments`
--

CREATE TABLE `departments` (
  `id` int(10) UNSIGNED NOT NULL,
  `department_name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `coordinator_id` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `departments`
--

INSERT INTO `departments` (`id`, `department_name`, `coordinator_id`, `created_at`, `updated_at`) VALUES
(1, 'BIT', '3', '2018-03-08 02:04:57', '2018-03-08 02:04:57'),
(2, 'CIS', '4', '2018-03-08 02:05:49', '2018-03-08 02:05:49'),
(3, 'CSE', '5', '2018-03-08 02:05:55', '2018-03-08 02:05:55');

-- --------------------------------------------------------

--
-- Table structure for table `ideas`
--

CREATE TABLE `ideas` (
  `id` int(10) UNSIGNED NOT NULL,
  `idea_title` varchar(200) COLLATE utf8mb4_unicode_ci NOT NULL,
  `idea_description` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `user_id` int(10) UNSIGNED NOT NULL,
  `category_id` int(10) UNSIGNED NOT NULL,
  `file_data` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `closer_date` date DEFAULT NULL,
  `publication_status` tinyint(4) DEFAULT NULL,
  `anonymous_post` tinyint(4) NOT NULL,
  `views` int(11) NOT NULL DEFAULT '0',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `ideas`
--

INSERT INTO `ideas` (`id`, `idea_title`, `idea_description`, `user_id`, `category_id`, `file_data`, `closer_date`, `publication_status`, `anonymous_post`, `views`, `created_at`, `updated_at`) VALUES
(1, 'jhgjh', 'hjhjg', 1, 1, NULL, '2018-03-23', 1, 0, 0, '2018-03-05 13:17:57', '2018-03-20 00:26:57'),
(2, 'i am nothing but everything', 'a dog is a a a good aniaml', 8, 4, NULL, '2018-04-25', 1, 0, 65, '2018-03-09 02:42:48', '2018-04-01 13:14:06'),
(3, 'hi CSE', 'kjld asdf jkladsjf kjsdlf jkalsdkjf lakdsjfl kjasdlfkj ladskjf lkjdslkfj aldskjf ladskjf ljdjf alasdjfal kdjladjf ljdfl jdsljf ladksf ljdlf ajldjf df', 5, 4, 'Asset/files/DSC_9159.JPG', '2018-04-25', 1, 0, 6, '2018-03-09 12:42:16', '2018-04-04 01:57:20'),
(4, 'hi', 'himu', 3, 3, 'Asset/files/golf-3840x2160-002.jpg', '2018-03-06', 1, 0, 0, '2018-03-10 00:59:42', '2018-03-20 01:29:24'),
(5, 'dasdf', 'asdffasd', 3, 4, NULL, NULL, 1, 0, 0, '2018-03-10 01:15:30', '2018-03-10 10:16:54'),
(6, 'mbjh', 'dgfd', 1, 3, NULL, NULL, 1, 0, 0, '2018-03-10 01:15:44', '2018-03-10 10:17:00'),
(7, 'jhkakjdf', 'kjasdhf', 1, 3, 'Asset/files/WIN_20170509_12_32_48_Pro.jpg', NULL, 1, 0, 0, '2018-03-10 02:13:29', '2018-03-10 10:17:04'),
(8, 'jkasdhkh', 'jkhasdkh', 8, 4, 'Asset/files/00159126_HIMANGSHU_DAS_DDD_DEC_2017-1.docx', NULL, NULL, 0, 0, '2018-03-10 02:23:42', '2018-03-10 02:23:42'),
(9, 'hajsk', 'jhdaskhf', 1, 3, 'Asset/files/00159126_HIMANGSHU_DAS_DDD_DEC_2017-1.docx', NULL, 1, 0, 0, '2018-03-10 02:23:56', '2018-03-10 10:17:06'),
(10, 'kjdshv', 'hjskjdfh', 1, 3, NULL, NULL, NULL, 0, 0, '2018-03-10 02:28:06', '2018-03-10 02:28:06'),
(11, 'kkashdh', 'hjafksjd', 1, 4, 'Asset/files/DSC_0284.JPG', NULL, NULL, 0, 0, '2018-03-10 02:35:22', '2018-03-10 02:35:22'),
(12, 'kajd', 'kjadba', 7, 3, 'Asset/files/0131479415.Prentice.Hall.Agile Estimating and Planning.pdf', NULL, NULL, 0, 0, '2018-03-10 12:01:37', '2018-03-10 12:01:37'),
(13, 'kjndkjd', 'jkadsk', 7, 4, 'Asset/files/DSC_0284.JPG', NULL, NULL, 0, 0, '2018-03-10 12:04:41', '2018-03-10 12:04:41'),
(14, 'jhd', 'HJASDJAH', 7, 4, 'Asset/files/DSC_0284.JPG', NULL, NULL, 0, 0, '2018-03-10 12:05:29', '2018-03-10 12:05:29'),
(15, 'kjaf', 'kjdfa', 1, 5, NULL, NULL, 1, 1, 0, '2018-03-12 03:49:34', '2018-03-12 03:50:11'),
(16, 'sdfa', 'asdfasd', 1, 5, NULL, NULL, 1, 1, 0, '2018-03-12 04:14:57', '2018-03-12 04:15:16'),
(17, 'askjdfhaksdh', 'jkahsdkfhaksdhf', 1, 5, 'Asset/files/DSC_9159.JPG', NULL, 1, 0, 0, '2018-03-12 07:03:43', '2018-03-12 07:04:04'),
(18, 'library', 'yzgegab yehgsg', 9, 6, 'Asset/files/DSC_0290.JPG', '2018-03-31', 1, 1, 0, '2018-03-18 06:53:54', '2018-03-20 00:48:34'),
(19, 'asd', 'sdf', 1, 6, 'Asset/files/ewsd_hi.sql', NULL, NULL, 1, 0, '2018-03-20 02:30:31', '2018-03-20 02:30:31'),
(20, 'adsa', 'sadas', 10, 6, 'Asset/files/ewsd_hi.sql', NULL, NULL, 1, 0, '2018-03-20 03:09:25', '2018-03-20 03:09:25'),
(21, 'hadsaj', 'hjadja', 10, 6, 'Asset/files/ewsd_hi.sql', NULL, NULL, 0, 0, '2018-03-20 03:10:00', '2018-03-20 03:10:00'),
(22, 'hadsaj', 'hjadja', 10, 6, 'Asset/files/ewsd_hi.sql', NULL, NULL, 0, 0, '2018-03-20 03:10:38', '2018-03-20 03:10:38'),
(23, 'this is a importent idea', 'and i am worthy of it', 10, 6, NULL, '2018-03-31', 1, 0, 6, '2018-03-20 05:34:50', '2018-03-20 08:22:36'),
(24, 'i am CSE Student', 'i want a smart lab in our department', 8, 6, NULL, NULL, NULL, 1, 1, '2018-03-20 08:49:55', '2018-03-20 08:49:55'),
(25, 'i am a female student', 'jaljf lkdsjf laksjdlfkj alsjdfl kajsdlfjlasjdf asjdlf', 9, 6, NULL, NULL, NULL, 0, 0, '2018-03-20 09:37:55', '2018-03-20 09:37:55'),
(26, 'i am a female student', 'jaljf lkdsjf laksjdlfkj alsjdfl kajsdlfjlasjdf asjdlf', 9, 6, NULL, NULL, NULL, 0, 0, '2018-03-20 09:42:45', '2018-03-20 09:42:45'),
(27, 'raihan is mad', 'raihan is a chagal baz', 10, 6, NULL, NULL, NULL, 0, 0, '2018-03-20 09:45:17', '2018-03-20 09:45:17'),
(28, 'ajfdakj', 'hakjdfhakj', 10, 6, NULL, NULL, NULL, 1, 0, '2018-03-20 09:58:55', '2018-03-20 09:58:55'),
(29, 'hellow', 'i am ok', 10, 6, NULL, NULL, NULL, 0, 0, '2018-03-20 10:00:15', '2018-03-20 10:00:15'),
(30, 'jhchjdsha', 'hjasjdhfaj', 10, 6, NULL, '2018-03-30', 1, 0, 0, '2018-03-20 10:01:41', '2018-03-21 04:25:40'),
(31, 'jkdfak', 'kjasdkj', 10, 6, NULL, '2018-03-30', 1, 0, 3, '2018-03-20 10:08:55', '2018-03-20 11:01:06'),
(32, 'Library should be more student friendly', 'In most of the cases, rivers start at the highest point in a particular area. Again, it’s very important source for fresh water. It’s quite surprising to know that rivers drain almost 75 percent of the earth’s land.', 10, 4, 'Asset/files/golf-3840x2160-002.jpg', '2018-03-31', 1, 1, 127, '2018-03-21 11:43:56', '2018-03-21 11:44:42'),
(33, 'i want to be king', 'jlkdjfaksdjlfajsdl jalsdjf ladsjfl jsdlfj lasdjfl jsdlfja lsdfjalsdjflj sdlfjalsdj \r\n flskjdflksdj fljsdl kfjalsdjflkajsdflkj \r\n asld kfjalksdjflk sadjflkajsdflkjasld kfjl aksjdfl kasjdflkjasdlfkj dfj sdfj dslfj sdjf adjlf alsdfj aldsjf aljdsf', 7, 4, NULL, NULL, 1, 0, 0, '2018-03-23 02:28:38', '2018-03-23 02:28:38'),
(34, 'rquwer wqer', 'erqwer', 1, 4, NULL, NULL, NULL, 1, 0, '2018-03-28 02:15:44', '2018-03-28 02:15:44'),
(35, 'rquwer wqer', 'erqwer', 1, 4, NULL, NULL, NULL, 1, 0, '2018-03-28 02:16:07', '2018-03-28 02:16:07'),
(36, '-------------------------------------', 'werwer', 1, 4, NULL, NULL, NULL, 1, 0, '2018-03-28 02:20:00', '2018-03-28 02:20:00'),
(37, '---', 'kkk', 1, 4, NULL, NULL, NULL, 1, 0, '2018-03-28 02:28:25', '2018-03-28 02:28:25');

-- --------------------------------------------------------

--
-- Table structure for table `like_dislikes`
--

CREATE TABLE `like_dislikes` (
  `id` int(10) UNSIGNED NOT NULL,
  `idea_id` int(10) UNSIGNED NOT NULL,
  `like` int(11) DEFAULT NULL,
  `dislike` int(11) DEFAULT NULL,
  `user_id` int(10) UNSIGNED NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `like_dislikes`
--

INSERT INTO `like_dislikes` (`id`, `idea_id`, `like`, `dislike`, `user_id`, `created_at`, `updated_at`) VALUES
(2, 17, 1, 0, 1, '2018-03-17 04:48:05', '2018-03-17 04:48:05'),
(4, 17, 1, 0, 7, '2018-03-17 11:41:28', '2018-03-17 11:41:28'),
(8, 16, 1, 0, 7, '2018-03-17 12:48:49', '2018-03-17 12:48:49'),
(9, 17, 0, 1, 1, '2018-03-18 06:32:31', '2018-03-18 06:32:31'),
(10, 18, 1, 0, 9, '2018-03-18 06:56:17', '2018-03-18 06:56:17'),
(11, 18, 1, 0, 1, '2018-03-18 07:43:12', '2018-03-18 07:43:12'),
(21, 31, 1, 0, 1, '2018-03-20 11:51:36', '2018-03-20 11:51:36'),
(22, 23, 1, 0, 1, '2018-03-20 12:46:22', '2018-03-20 12:46:22'),
(24, 31, 1, 0, 10, '2018-03-20 13:12:25', '2018-03-20 13:12:25'),
(25, 18, 0, 1, 10, '2018-03-20 13:14:25', '2018-03-20 13:14:25'),
(26, 4, 1, 0, 10, '2018-03-20 13:29:26', '2018-03-20 13:29:26'),
(27, 31, 0, 1, 6, '2018-03-21 03:40:53', '2018-03-21 03:40:53'),
(28, 31, 1, 0, 2, '2018-03-22 00:12:45', '2018-03-22 00:12:45'),
(29, 32, 1, 0, 2, '2018-03-22 00:47:59', '2018-03-22 00:47:59'),
(30, 32, 1, 0, 3, '2018-03-25 07:39:33', '2018-03-25 07:39:33'),
(31, 32, 0, 1, 1, '2018-03-27 11:47:20', '2018-03-27 11:47:20'),
(32, 2, 0, 1, 2, '2018-04-01 13:14:21', '2018-04-01 13:14:21'),
(33, 2, 0, 1, 10, '2018-04-01 16:40:59', '2018-04-01 16:40:59'),
(34, 2, 0, 1, 1, '2018-04-01 17:09:31', '2018-04-01 17:09:31'),
(35, 3, 1, 0, 2, '2018-04-04 01:57:48', '2018-04-04 01:57:48');

-- --------------------------------------------------------

--
-- Table structure for table `migrations`
--

CREATE TABLE `migrations` (
  `id` int(10) UNSIGNED NOT NULL,
  `migration` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `batch` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `migrations`
--

INSERT INTO `migrations` (`id`, `migration`, `batch`) VALUES
(19, '2014_10_12_000000_create_users_table', 1),
(20, '2014_10_12_100000_create_password_resets_table', 1),
(21, '2018_02_19_053753_create_categories_table', 1),
(22, '2018_02_19_065231_create_ideas_table', 1),
(23, '2018_02_22_073126_create_comments_table', 1),
(29, '2018_02_24_140459_create_like_dislikes_table', 2),
(30, '2018_02_27_080206_create_admins_table', 2),
(31, '2018_02_28_045531_create_roles_table', 2),
(32, '2018_02_28_050722_create_user_role_table', 2),
(33, '2018_03_08_052146_create_departments_table', 2),
(34, '2018_03_20_212135_create_profiles_table', 3),
(35, '2018_03_22_073331_create_views_table', 4);

-- --------------------------------------------------------

--
-- Table structure for table `password_resets`
--

CREATE TABLE `password_resets` (
  `email` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `token` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `profiles`
--

CREATE TABLE `profiles` (
  `id` int(10) UNSIGNED NOT NULL,
  `user_id` int(11) NOT NULL,
  `user_name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `image` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `profiles`
--

INSERT INTO `profiles` (`id`, `user_id`, `user_name`, `image`, `created_at`, `updated_at`) VALUES
(2, 1, 'himu', 'Asset/files/Windows_10_4k_Wallpapers-11.jpg', NULL, NULL),
(3, 10, 'raihan', 'Asset/files/selfie1.jpg', NULL, NULL),
(4, 7, 'hiu', 'Asset/files/2017-10-29.png', NULL, NULL),
(6, 6, 'picture', 'Asset/files/sad_smiley_face_classic_round_sticker-r364e0eed23d248b982dc0b717710afc1_v9wth_8byvr_324.jpg', NULL, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `roles`
--

CREATE TABLE `roles` (
  `id` int(10) UNSIGNED NOT NULL,
  `user_id` int(11) NOT NULL,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `department_id` int(11) NOT NULL,
  `remember_token` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `roles`
--

INSERT INTO `roles` (`id`, `user_id`, `name`, `department_id`, `remember_token`, `created_at`, `updated_at`) VALUES
(1, 2, 'manager', 0, NULL, NULL, NULL),
(2, 1, 'student', 1, NULL, '2018-03-08 00:44:02', '2018-03-08 00:44:02'),
(3, 3, 'coordinator', 1, NULL, '2018-03-08 00:44:09', '2018-03-08 00:44:09'),
(4, 4, 'coordinator', 2, NULL, '2018-03-08 00:46:07', '2018-03-08 00:46:07'),
(5, 6, 'coordinator', 3, NULL, '2018-03-08 00:46:17', '2018-03-08 00:46:17'),
(6, 7, 'student', 3, NULL, '2018-03-09 02:36:00', '2018-03-09 02:36:00'),
(7, 8, 'student', 2, NULL, '2018-03-09 02:36:14', '2018-03-09 02:36:14'),
(8, 5, 'coor', 3, NULL, '2018-03-09 12:39:37', '2018-03-09 12:39:37'),
(9, 9, 'student', 3, NULL, '2018-03-18 06:45:52', '2018-03-18 06:45:52'),
(10, 10, 'student', 2, NULL, '2018-03-20 03:08:47', '2018-03-20 03:08:47'),
(11, 11, 'Superadmin', 0, NULL, NULL, NULL),
(12, 12, 'student', 3, NULL, '2018-03-27 13:45:46', '2018-03-27 13:45:46');

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `id` int(10) UNSIGNED NOT NULL,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `email` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `password` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `remember_token` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `name`, `email`, `password`, `remember_token`, `created_at`, `updated_at`) VALUES
(1, 'Himangshu Das', 'himu@gmail.com', '$2y$10$oeQieLaTLvKZsJfa1ac9U.owDMVX75m8pqdQOyU39IVMyvXwNKX.K', 'WnVk6RmbgVxzqhrFlY9EJ5B8UsFnKTsCQ1VIxiMSjw4g6MXvFlRKcgVeIJVW', '2018-03-05 11:48:16', '2018-03-24 07:36:04'),
(2, 'raihan', '1000305@daffodil.ac', '$2y$10$HvaiP3I7C8EzsqXC.RemQe0.wnE5e6O3D.Mn0rRFAeuDWkTye8Mke', 'JJqnNMK5eJdTI2wp9jdKuG2h482mKlGhQwhaegNiEvBKSV25h12Sn2wGZHC3', '2018-03-05 12:06:47', '2018-03-05 12:06:47'),
(3, 'misuk', 'misuk@gmail.com', '$2y$10$ISlGRvLsxQjmDpEL5TyA1eeOFCCjj8deHi5y4wp3WYyoXZGpuPts2', 'n8hDNMK4m3pVg0p2N9YE4tQGXep0q8rvuaGTctKJ3AYeqSkLtwLDjrnJBiPq', '2018-03-05 23:57:36', '2018-03-05 23:57:36'),
(4, 'hhhh', '1000312@daffodil.ac', '$2y$10$SnI3L0Vh8Kk8v1qeRo60B.QLgYDZ9YrJW5I57jmbG76m.r0OjGIVi', 'C05dLoanxpog06UUT3WL2bg0wS6O95AFY9Jt090CsiEwwg5GUjeWyMRxpgx5', '2018-03-06 02:44:40', '2018-03-06 02:44:40'),
(5, 'jjjj', 'j@gmail.com', '$2y$10$NbK587JJJrI6nvhFa1WVxe3wHZTi6NWMSIo8zJJ.3I/mh6egR51cS', '0FQocm6iE1zKQSzoMznGS4mQAtyxgEFdUhSjlIQV3yZWjACO3eMcbiQ2bb9U', '2018-03-06 22:24:49', '2018-03-06 22:24:49'),
(6, 'MD. navi', 'navi23@gmail.com', '$2y$10$1fpZhpalXjEljHe1t7vBKOZiV1C5aC4WSHEnc3KBIS7rahEzDdqp.', 'C2oDqtgUqToHBYz8A8XCRdtImshwmesuWeelEjK69ipZbvoPJ8FGFIlYcZUT', '2018-03-06 23:19:02', '2018-03-21 03:38:46'),
(7, 'navi', 'navi2@gmail.com', '$2y$10$1vzoqfzjh.Vqnyr.oTQLt.VOInAbVwuAk6tCh5oY1jAB7tNSi4EZ.', 'vA1sc6IQgJmnUK6w66OnetSNhEKV6PLB4STiybMJxrxioPQU5cxr39Beujok', '2018-03-07 07:20:13', '2018-03-07 07:20:13'),
(8, 'himu', 'as@gmail.com', '$2y$10$tCC97.EzmmTs8Z.rBa5nn.IaCKsSOxk9zgtB97NBzLM/MZ9ZAz1eq', 'O6Ypq84A0oV87Xj1z7vKdQVsYbv6G5zecjv8DTJW2R2q2AKD0CtKKZTMkR8W', '2018-03-07 10:58:06', '2018-03-07 10:58:06'),
(9, 'afia', 'afia@gmail.com', '$2y$10$U.J9KdY5p47lGSljysFVd.14vqX/FD1ZgKv2.VJcy/JiVIwDI2582', '11LM8DreacQjfdeUv1oqN5xijAhlEGouprkqnNY3TUoZLuqDyZjQ7qg9KSY5', '2018-03-18 06:41:06', '2018-03-18 06:41:06'),
(10, 'chinmoy', 'chinmoy221219@gmail.com', '$2y$10$/ape/coLiMudO8bkUZ50M.NUNZPRzZnnxuUtBAoERcVpumaPXHKue', 'MSaDXodPZXyCk4HPLsQsWWn1xQG72cwjLzqn2WzO5kDEg4ZA1tcS96JS6bmS', '2018-03-20 03:03:57', '2018-03-21 07:36:31'),
(11, 'motus', 'motu@gmail.com', '$2y$10$n3QGguEAcg/lXLg/YIlyzuVRKZYpv9tvfn/g/O.iTL2ppH5sqKXh2', '8wsOs9ey1Dm3bqJ8Q8mBXto41qWPMmEAfl3iHn2zjBWsCs8nLBa59RXcLTcB', '2018-03-20 15:09:10', '2018-03-20 15:09:10'),
(12, 'himan', 'himan@gmail.com', '$2y$10$BVs0H9WqAEA8GmCE2CmKsuIDRuJ299MZy7nru2Q53ZXuc8EsHSgcW', NULL, '2018-03-23 02:59:52', '2018-03-23 02:59:52'),
(13, 'hero', '12@gmail.com', '$2y$10$QIuJDSdzbno56EnjOB3Ehu4XBwnFhStauqfcOBnSv18cO8SckMViO', NULL, '2018-03-23 03:04:18', '2018-03-23 03:04:18'),
(14, 'daffodil', 'daffodil@gmail.com', '$2y$10$fIPHfAG3VawbBwD0LeTUreytv4RQDQErU5xvE.ebjhTcVwppdlu7i', NULL, '2018-03-25 07:22:36', '2018-03-25 07:22:36'),
(15, 'Raihan kabir', 'raihankbr50@gmail.com', '$2y$10$oSq9nnjtQWaQ41VfdfAO/u2V0oimuOik4DcaVdM32ysyXDNgovZXy', NULL, '2018-03-27 12:36:28', '2018-03-27 12:36:28');

-- --------------------------------------------------------

--
-- Table structure for table `views`
--

CREATE TABLE `views` (
  `id` int(10) UNSIGNED NOT NULL,
  `idea_id` int(11) NOT NULL,
  `click` int(11) NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `views`
--

INSERT INTO `views` (`id`, `idea_id`, `click`, `created_at`, `updated_at`) VALUES
(1, 1, 2, NULL, NULL);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `admins`
--
ALTER TABLE `admins`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `admins_email_unique` (`email`);

--
-- Indexes for table `categories`
--
ALTER TABLE `categories`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `comments`
--
ALTER TABLE `comments`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `departments`
--
ALTER TABLE `departments`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `ideas`
--
ALTER TABLE `ideas`
  ADD PRIMARY KEY (`id`),
  ADD KEY `ideas_category_id_foreign` (`category_id`),
  ADD KEY `ideas_user_id_foreign` (`user_id`);

--
-- Indexes for table `like_dislikes`
--
ALTER TABLE `like_dislikes`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `migrations`
--
ALTER TABLE `migrations`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `password_resets`
--
ALTER TABLE `password_resets`
  ADD KEY `password_resets_email_index` (`email`);

--
-- Indexes for table `profiles`
--
ALTER TABLE `profiles`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `roles`
--
ALTER TABLE `roles`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `users_email_unique` (`email`);

--
-- Indexes for table `views`
--
ALTER TABLE `views`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `admins`
--
ALTER TABLE `admins`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `categories`
--
ALTER TABLE `categories`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;
--
-- AUTO_INCREMENT for table `comments`
--
ALTER TABLE `comments`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=52;
--
-- AUTO_INCREMENT for table `departments`
--
ALTER TABLE `departments`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;
--
-- AUTO_INCREMENT for table `ideas`
--
ALTER TABLE `ideas`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=38;
--
-- AUTO_INCREMENT for table `like_dislikes`
--
ALTER TABLE `like_dislikes`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=36;
--
-- AUTO_INCREMENT for table `migrations`
--
ALTER TABLE `migrations`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=36;
--
-- AUTO_INCREMENT for table `profiles`
--
ALTER TABLE `profiles`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;
--
-- AUTO_INCREMENT for table `roles`
--
ALTER TABLE `roles`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=13;
--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=16;
--
-- AUTO_INCREMENT for table `views`
--
ALTER TABLE `views`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;
--
-- Constraints for dumped tables
--

--
-- Constraints for table `ideas`
--
ALTER TABLE `ideas`
  ADD CONSTRAINT `ideas_category_id_foreign` FOREIGN KEY (`category_id`) REFERENCES `categories` (`id`),
  ADD CONSTRAINT `ideas_user_id_foreign` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`);

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
